/*global MktoForms2 */
MktoForms2.loadForm('//app-ab06.marketo.com', '022-DQH-814', 1223, function(form) {
    form.getFormElem().hide();
    document.getElementById('newsletterLink').addEventListener('click', function() {
        form.getFormElem().show();
        MktoForms2.lightbox(form).show();
    });
});

/*eslint no-var:0*/
(function(window) {
    var predix = window.predix || {};

    function init(id) {
        $('#' + id).slick({
            dots: true,
            arrows: false,
            autoplay: true,
            autoplaySpeed: 150000,
            customPaging: function() {
                return '<div class="px-carousel__dot"><i class="fa fa-circle" data-qa="carousel-dot-link"></i></div>';
            },
            dotsClass: 'px-carousel list-inline text--center'
        });
    }

    predix.helpers = predix.helpers || {};

    predix.helpers.carousel = {
        init: init
    };
    window.predix = predix;
})(window);
